# Multilingual financial CX sentiment — sampling and Codex starter

- `cx_sentiment_test_600.csv` / `.jsonl`: locked 600-row final test sample; 100 rows per language, 200 per sentiment class, sourced only from original `test.csv`.
- `sample_manifest.json`: sampling strata, source archive checksum, and quality checks.
- `make_sample.py`: reproducible regeneration; place original `financial_sentiment_hf_v2.zip` alongside the `cx_sentiment_starter` folder or adapt SOURCE in the script.
- `CODEX_PROMPT.md`: paste into Codex along with files, to implement the POC.

**Important:** Original validation data remain in the source ZIP. Do not tune models, prompts, or routing thresholds on this test sample. Near-duplicate templates may exist despite exact deduplication.
