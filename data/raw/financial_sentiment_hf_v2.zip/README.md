# Financial customer feedback synthetic dataset — revised v2

Synthetic multilingual sentiment dataset (PT, EN, ES, FR, DE, IT). Sentiment mapping: negative=0, neutral=1, positive=2.

Splits (after global exact-text deduplication): {'train': 11734, 'validation': 2929, 'test': 2932}

Revision: removed duplicated phrases, cleaned formatting, deduplicated exact comments across splits. Retained formulaic customer wording deliberately. Original source uses 108 seed sentences and many templated variations; near-duplicate and template leakage may remain. Not an independent real-world benchmark.

Load using `load_dataset("json", data_files={"train":"train.jsonl", "validation":"validation.jsonl", "test":"test.jsonl"})` after extraction.
