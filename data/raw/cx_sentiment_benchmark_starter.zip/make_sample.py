"""Deterministically sample 600 balanced held-out CX comments from source ZIP."""
import csv
import hashlib
import io
import json
import random
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

SOURCE = Path(__file__).resolve().parent.parent / 'financial_sentiment_hf_v2.zip'
OUT = Path(__file__).resolve().parent
SEED = 20261015
LANGUAGES = ('pt', 'en', 'es', 'fr', 'de', 'it')
CLASSES = ('negative', 'neutral', 'positive')

with zipfile.ZipFile(SOURCE) as z:
    splits = {s: list(csv.DictReader(io.StringIO(z.read(f'{s}.csv').decode('utf-8-sig')))) for s in ('train', 'validation', 'test')}

def normalized(text):
    return ' '.join(text.casefold().split())

# Hold-out sampling exclusively from test. 100/language and 200/sentiment;
# rotate which class gets 34 per language, remaining cells get 33.
rng = random.Random(SEED)
groups = defaultdict(list)
for idx, rec in enumerate(splits['test']):
    groups[(rec['language'], rec['sentiment'])].append((idx,rec))
selected = []
counts = {}
for i, lang in enumerate(LANGUAGES):
    for j, sentiment in enumerate(CLASSES):
        target = 34 if j == i % 3 else 33
        sample = rng.sample(groups[(lang,sentiment)], target)
        selected.extend(sample)
        counts[f'{lang}/{sentiment}'] = target
rng.shuffle(selected)

rows = []
for idx, rec in selected:
    raw = rec['text']
    rows.append({
        'sample_id': 'cx_' + hashlib.sha256(f'test:{idx}:{raw}'.encode()).hexdigest()[:16],
        'source_split': 'test',
        'source_row_index_zero_based': idx,
        'language': rec['language'],
        'text': raw,
        'sentiment': rec['sentiment'],
        'label': int(rec['label'])
    })
assert len(rows)==600 and len({r['sample_id'] for r in rows})==600
assert Counter(r['language'] for r in rows) == {x: 100 for x in LANGUAGES}
assert Counter(r['sentiment'] for r in rows) == {x: 200 for x in CLASSES}
assert len({normalized(r['text']) for r in rows}) == 600
other_texts={normalized(r['text']) for split in ('train','validation') for r in splits[split]}
assert not {normalized(r['text']) for r in rows} & other_texts, 'Cross-split exact normalized duplicate!'

with (OUT/'cx_sentiment_test_600.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
with (OUT/'cx_sentiment_test_600.jsonl').open('w', encoding='utf-8') as f:
    for r in rows: f.write(json.dumps(r, ensure_ascii=False)+'\n')
manifest = {
    'source_archive': SOURCE.name,
    'source_archive_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'source_split': 'test',
    'sampling_seed': SEED,
    'selection': 'stratified by language x sentiment with rotated remainder to balance language and class totals',
    'n_rows': len(rows),
    'languages': dict(Counter(r['language'] for r in rows)),
    'sentiments': dict(Counter(r['sentiment'] for r in rows)),
    'strata': counts,
    'validation': 'No within-sample normalized exact duplicates; none overlap train/validation under casefold+whitespace normalization.',
    'known_limitation': 'Synthetic template variations from 108 seed sentences; semantic near-duplicates across splits possible. Not independent real-world CX.',
    'do_not_use_for': 'Threshold selection, prompt development, model selection, training or repeated leaderboard tuning. Use original validation.csv for threshold tuning.'
}
(OUT/'sample_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print('Created',len(rows),'records in',OUT)
